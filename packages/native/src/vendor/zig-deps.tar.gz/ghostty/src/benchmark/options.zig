//! This file contains helpers for CLI options.

const std = @import("std");
const global = @import("../global.zig");

/// Returns the data file for the given path in a way that is consistent
/// across our CLI. If the path is not set then no file is returned.
/// If the path is "-", then we will return stdin. If the path is
/// a file then we will open and return the handle.
pub fn dataFile(path_: ?[]const u8) !?std.Io.File {
    const path = path_ orelse return null;

    // Stdin
    if (std.mem.eql(u8, path, "-")) return .stdin();

    // Normal file
    const file = try std.Io.Dir.cwd().openFile(global.io(), path, .{});
    errdefer file.close(global.io());

    return file;
}
