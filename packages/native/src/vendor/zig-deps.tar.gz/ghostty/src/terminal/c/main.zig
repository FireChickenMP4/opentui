const lib = @import("../lib.zig");
const CAllocator = lib.alloc.Allocator;

const buildpkg = @import("build_info.zig");
pub const allocator = @import("allocator.zig");
pub const cell = @import("cell.zig");
pub const color = @import("color.zig");
pub const color_scheme = @import("color_scheme.zig");
pub const focus = @import("focus.zig");
pub const formatter = @import("formatter.zig");
pub const grid_ref = @import("grid_ref.zig");
pub const grid_ref_tracked = @import("grid_ref_tracked.zig");
pub const io = @import("io.zig");
pub const kitty_graphics = @import("kitty_graphics.zig");
pub const kitty_graphics_get = kitty_graphics.get;
pub const kitty_graphics_image = kitty_graphics.image_get_handle;
pub const kitty_graphics_image_get = kitty_graphics.image_get;
pub const kitty_graphics_image_get_multi = kitty_graphics.image_get_multi;
pub const kitty_graphics_placement_iterator_new = kitty_graphics.placement_iterator_new;
pub const kitty_graphics_placement_iterator_free = kitty_graphics.placement_iterator_free;
pub const kitty_graphics_placement_iterator_set = kitty_graphics.placement_iterator_set;
pub const kitty_graphics_placement_next = kitty_graphics.placement_iterator_next;
pub const kitty_graphics_placement_get = kitty_graphics.placement_get;
pub const kitty_graphics_placement_get_multi = kitty_graphics.placement_get_multi;
pub const kitty_graphics_placement_rect = kitty_graphics.placement_rect;
pub const kitty_graphics_placement_pixel_size = kitty_graphics.placement_pixel_size;
pub const kitty_graphics_placement_grid_size = kitty_graphics.placement_grid_size;
pub const kitty_graphics_placement_viewport_pos = kitty_graphics.placement_viewport_pos;
pub const kitty_graphics_placement_source_rect = kitty_graphics.placement_source_rect;
pub const kitty_graphics_placement_render_info = kitty_graphics.placement_render_info;
pub const types = @import("types.zig");
pub const modes = @import("modes.zig");
pub const osc = @import("osc.zig");
pub const render = @import("render.zig");
pub const selection = @import("selection.zig");
pub const selection_gesture = @import("selection_gesture.zig");
pub const key_event = @import("key_event.zig");
pub const key_encode = @import("key_encode.zig");
pub const mouse_event = @import("mouse_event.zig");
pub const mouse_encode = @import("mouse_encode.zig");
pub const paste = @import("paste.zig");
pub const row = @import("row.zig");
pub const sgr = @import("sgr.zig");
pub const size_report = @import("size_report.zig");
pub const snapshot = @import("snapshot.zig");
pub const style = @import("style.zig");
pub const sys = @import("sys.zig");
pub const terminal = @import("terminal.zig");
pub const unicode = @import("unicode.zig");

// The full C API, unexported.
pub const build_info = buildpkg.get;

pub const osc_new = osc.new;
pub const osc_free = osc.free;
pub const osc_reset = osc.reset;
pub const osc_next = osc.next;
pub const osc_end = osc.end;
pub const osc_command_type = osc.commandType;
pub const osc_command_data = osc.commandData;

pub const color_rgb_get = color.rgb_get;
pub const color_contrast = color.contrast;
pub const color_luminance = color.luminance;
pub const color_parse = color.parse;
pub const color_parse_palette_entry = color.parse_palette_entry;
pub const color_parse_x11 = color.parse_x11;
pub const color_palette_default = color.palette_default;
pub const color_palette_generate = color.palette_generate;
pub const color_perceived_luminance = color.perceived_luminance;
pub const color_x11_name_count = color.x11_name_count;
pub const color_x11_names = color.x11_names;

pub const color_scheme_report_encode = color_scheme.report_encode;

pub const focus_encode = focus.encode;

pub const mode_report_encode = modes.report_encode;

pub const formatter_terminal_new = formatter.terminal_new;
pub const formatter_format_buf = formatter.format_buf;
pub const formatter_format_alloc = formatter.format_alloc;
pub const formatter_free = formatter.free;

pub const render_state_new = render.new;
pub const render_state_free = render.free;
pub const render_state_update = render.update;
pub const render_state_begin_update = render.begin_update;
pub const render_state_end_update = render.end_update;
pub const render_state_get = render.get;
pub const render_state_get_multi = render.get_multi;
pub const render_state_set = render.set;
pub const render_state_colors_get = render.colors_get;
pub const render_state_row_iterator_new = render.row_iterator_new;
pub const render_state_row_iterator_next = render.row_iterator_next;
pub const render_state_row_get = render.row_get;
pub const render_state_row_get_multi = render.row_get_multi;
pub const render_state_row_set = render.row_set;
pub const render_state_row_iterator_free = render.row_iterator_free;
pub const render_state_row_cells_new = render.row_cells_new;
pub const render_state_row_cells_next = render.row_cells_next;
pub const render_state_row_cells_select = render.row_cells_select;
pub const render_state_row_cells_get = render.row_cells_get;
pub const render_state_row_cells_get_multi = render.row_cells_get_multi;
pub const render_state_row_cells_free = render.row_cells_free;

pub const sgr_new = sgr.new;
pub const sgr_free = sgr.free;
pub const sgr_reset = sgr.reset;
pub const sgr_set_params = sgr.setParams;
pub const sgr_next = sgr.next;
pub const sgr_unknown_full = sgr.unknown_full;
pub const sgr_unknown_partial = sgr.unknown_partial;
pub const sgr_attribute_tag = sgr.attribute_tag;
pub const sgr_attribute_value = sgr.attribute_value;
pub const wasm_alloc_sgr_attribute = sgr.wasm_alloc_attribute;
pub const wasm_free_sgr_attribute = sgr.wasm_free_attribute;

pub const key_event_new = key_event.new;
pub const key_event_free = key_event.free;
pub const key_event_set_action = key_event.set_action;
pub const key_event_get_action = key_event.get_action;
pub const key_event_set_key = key_event.set_key;
pub const key_event_get_key = key_event.get_key;
pub const key_event_set_mods = key_event.set_mods;
pub const key_event_get_mods = key_event.get_mods;
pub const key_event_set_consumed_mods = key_event.set_consumed_mods;
pub const key_event_get_consumed_mods = key_event.get_consumed_mods;
pub const key_event_set_composing = key_event.set_composing;
pub const key_event_get_composing = key_event.get_composing;
pub const key_event_set_utf8 = key_event.set_utf8;
pub const key_event_get_utf8 = key_event.get_utf8;
pub const key_event_set_unshifted_codepoint = key_event.set_unshifted_codepoint;
pub const key_event_get_unshifted_codepoint = key_event.get_unshifted_codepoint;

pub const key_encoder_new = key_encode.new;
pub const key_encoder_free = key_encode.free;
pub const key_encoder_setopt = key_encode.setopt;
pub const key_encoder_setopt_from_terminal = key_encode.setopt_from_terminal;
pub const key_encoder_encode = key_encode.encode;

pub const mouse_event_new = mouse_event.new;
pub const mouse_event_free = mouse_event.free;
pub const mouse_event_set_action = mouse_event.set_action;
pub const mouse_event_get_action = mouse_event.get_action;
pub const mouse_event_set_button = mouse_event.set_button;
pub const mouse_event_clear_button = mouse_event.clear_button;
pub const mouse_event_get_button = mouse_event.get_button;
pub const mouse_event_set_mods = mouse_event.set_mods;
pub const mouse_event_get_mods = mouse_event.get_mods;
pub const mouse_event_set_position = mouse_event.set_position;
pub const mouse_event_get_position = mouse_event.get_position;

pub const mouse_encoder_new = mouse_encode.new;
pub const mouse_encoder_free = mouse_encode.free;
pub const mouse_encoder_setopt = mouse_encode.setopt;
pub const mouse_encoder_setopt_from_terminal = mouse_encode.setopt_from_terminal;
pub const mouse_encoder_reset = mouse_encode.reset;
pub const mouse_encoder_encode = mouse_encode.encode;

pub const paste_is_safe = paste.is_safe;
pub const paste_encode = paste.encode;

pub const alloc_alloc = allocator.alloc;
pub const alloc_free = allocator.free;

pub const size_report_encode = size_report.encode;

pub const cell_get = cell.get;
pub const cell_get_multi = cell.get_multi;

pub const row_get = row.get;
pub const row_get_multi = row.get_multi;

pub const style_default = style.default_style;
pub const style_is_default = style.style_is_default;

pub const sys_log_stderr = sys.logStderr;
pub const sys_set = sys.set;

pub const terminal_new = terminal.new;
pub const terminal_free = terminal.free;
pub const terminal_reset = terminal.reset;
pub const terminal_resize = terminal.resize;
pub const terminal_set = terminal.set;
pub const terminal_vt_write = terminal.vt_write;
pub const terminal_scroll_viewport = terminal.scroll_viewport;
pub const terminal_compression_activity = terminal.compression_activity;
pub const terminal_compress = terminal.compress;
pub const terminal_mode_get = terminal.mode_get;
pub const terminal_mode_set = terminal.mode_set;
pub const terminal_get = terminal.get;
pub const terminal_get_multi = terminal.get_multi;
pub const terminal_continuation_write = terminal.continuation_write;
pub const terminal_continuation_buf = terminal.continuation_buf;
pub const terminal_continuation_alloc = terminal.continuation_alloc;
pub const terminal_select_word = selection.word;
pub const terminal_select_word_between = selection.word_between;
pub const terminal_select_line = selection.line;
pub const terminal_select_all = selection.all;
pub const terminal_select_output = selection.output;
pub const terminal_selection_format_buf = selection.format_buf;
pub const terminal_selection_format_alloc = selection.format_alloc;
pub const terminal_selection_adjust = selection.adjust;
pub const terminal_selection_order = selection.order;
pub const terminal_selection_ordered = selection.ordered;
pub const terminal_selection_contains = selection.contains;
pub const terminal_selection_equal = selection.equal;
pub const selection_gesture_new = selection_gesture.new;
pub const selection_gesture_free = selection_gesture.free;
pub const selection_gesture_reset = selection_gesture.reset;
pub const selection_gesture_event = selection_gesture.handle_event;
pub const selection_gesture_get = selection_gesture.get;
pub const selection_gesture_get_multi = selection_gesture.get_multi;
pub const selection_gesture_event_new = selection_gesture.event_new;
pub const selection_gesture_event_free = selection_gesture.event_free;
pub const selection_gesture_event_set = selection_gesture.event_set;
pub const terminal_grid_ref = terminal.grid_ref;
pub const terminal_grid_ref_track = terminal.grid_ref_track;
pub const terminal_point_from_grid_ref = terminal.point_from_grid_ref;

pub const snapshot_encode = snapshot.encode;
pub const snapshot_encode_buf = snapshot.encode_buf;
pub const snapshot_encode_alloc = snapshot.encode_alloc;
pub const snapshot_decoder_new = snapshot.decoder_new;
pub const snapshot_decoder_new_buf = snapshot.decoder_new_buf;
pub const snapshot_decoder_free = snapshot.decoder_free;
pub const snapshot_decoder_set = snapshot.decoder_set;
pub const snapshot_decoder_get = snapshot.decoder_get;
pub const snapshot_decoder_get_multi = snapshot.decoder_get_multi;
pub const snapshot_decoder_ready = snapshot.decoder_ready;
pub const snapshot_decoder_next = snapshot.decoder_next;
pub const snapshot_decoder_decode = snapshot.decoder_decode;

pub const type_json = types.get_json;

pub const unicode_codepoint_width = unicode.codepoint_width;
pub const unicode_grapheme_width = unicode.grapheme_width;

pub const grid_ref_cell = grid_ref.grid_ref_cell;
pub const grid_ref_row = grid_ref.grid_ref_row;
pub const grid_ref_graphemes = grid_ref.grid_ref_graphemes;
pub const grid_ref_hyperlink_uri = grid_ref.grid_ref_hyperlink_uri;
pub const grid_ref_style = grid_ref.grid_ref_style;
pub const tracked_grid_ref_free = grid_ref_tracked.tracked_grid_ref_free;
pub const tracked_grid_ref_has_value = grid_ref_tracked.tracked_grid_ref_has_value;
pub const tracked_grid_ref_point = grid_ref_tracked.tracked_grid_ref_point;
pub const tracked_grid_ref_set = grid_ref_tracked.tracked_grid_ref_set;
pub const tracked_grid_ref_snapshot = grid_ref_tracked.tracked_grid_ref_snapshot;

test {
    _ = allocator;
    _ = buildpkg;
    _ = cell;
    _ = color;
    _ = color_scheme;
    _ = grid_ref;
    _ = grid_ref_tracked;
    _ = io;
    _ = kitty_graphics;
    _ = row;
    _ = focus;
    _ = formatter;
    _ = modes;
    _ = osc;
    _ = render;
    _ = selection;
    _ = selection_gesture;
    _ = key_event;
    _ = key_encode;
    _ = mouse_event;
    _ = mouse_encode;
    _ = paste;
    _ = sgr;
    _ = size_report;
    _ = snapshot;
    _ = style;
    _ = sys;
    _ = terminal;
    _ = types;
    _ = unicode;

    // We want to make sure we run the tests for the C allocator interface.
    _ = @import("../../lib/allocator.zig");
}
